#include<stdio.h>
#include<conio.h>
int sum(int a,int b);
int multiply(int d, int c);
int average(int s, int e);
int subtraction(int h,int r);
void table (int c);

 
int main()
{
    int x;
    int z;
    int y;
    int n;
 
  
  
     
      x = sum(4,8);
      
    printf("the value of sum  is =%d\n",x);
     z =multiply(8,5);
    printf("the value of multiply  is =%d\n",z);
    y = sum(56,67);
    printf("the value of division is =%d\n",y/5);
    n = subtraction(190,80);
    printf("the value of subtraction  is =%d\n",n);
    table(12);
getch();
}






int sum(int a,int b)
{
    int x= a+b;
     return x;
      }
int multiply(int d, int c)
{
    int z = d*c; 
    return z;
    }
int average(int s, int e)
{
    int y = s/e;
    }
    int subtraction(int h,int r)
    {
        int n = h-r;
        return n;
        }
        void table (int c)
        {
              int e;
              for(e=1;e<=10;e++)
              printf("%dx%d =%d\n",c,e,c*e);
              
              }
