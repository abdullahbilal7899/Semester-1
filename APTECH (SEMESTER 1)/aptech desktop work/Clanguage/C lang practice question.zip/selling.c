#include<stdio.h>
#include<conio.h>
int main()
{
    int items = 15;
    int  profit;
    int  price;
    int division;
    int sum;
    printf("item is 15\n");
    printf("enter profit\n");
    scanf("%d",&profit);
    
    sum = profit+items;
    printf("cost price of one item is:%d\n",sum/5);
    
    
    
    
    getch();
    }
