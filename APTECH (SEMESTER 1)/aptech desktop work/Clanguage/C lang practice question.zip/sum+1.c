#include<stdio.h>
#include<conio.h>
int main()
{
    int a;
    int b;
    int c;
    int d;
    int e;
    int sum =1;
     
    scanf("%d",&a);
    printf("the value of a is :%d\n",a);
    
     sum = a+1;
     printf("the sum of a is :%d\n",sum); 
      
      
      scanf("%d",&b);
      printf("the value of b is :%d\n",b);
    
     sum = b+1;
     printf("the sum of b is :%d\n",sum); 
      
      
      scanf("%d",&c);
      printf("the value of c is :%d\n",c);
    
     sum = c+1;
     printf("the sum of c is :%d\n",sum); 
       
       
       scanf("%d",&d);
       printf("the value of d is :%d\n",d);
    
     sum = d+1;
     printf("the sum of d is :%d\n",sum); 
        
        
        scanf("%d",&e);
        printf("the value of e is :%d\n",e);
    
     sum = e+1;
     printf("the sum of e is :%d\n",sum); 
  
    
    
    getch();
    }
