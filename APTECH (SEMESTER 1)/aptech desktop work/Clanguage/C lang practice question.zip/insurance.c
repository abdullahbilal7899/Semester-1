#include<stdio.h>
#include<conio.h>
int main()
{
    int age;
    int premium1 =4;
    int premium2 =3;
    int premium3 =6;
    int amount1= 200000;
    int amount2= 100000;
    int amount3= 10000;
    char sex;
    char location;
    char health;
    char satisfy;
    int premium4= 3;
    int amount4= 100000;
    printf("enter your health\n");
    //scanf("%c",&health);
      health=getch();
 
          if(health == 'e')
          {
                    printf("person health is excellent\n");
                    }
                    else{
                    printf("person health is poor\n");
                    }
                    
    printf("enter sex: ");
    //scanf("%c",&sex);
    sex=getch();
    if(sex == 'm')
    {
               printf("person premium is :%d per thousand\n",premium1);
    }
    else
    {
        printf("person premium is:%d per thousand\n",premium3);
    }
        printf("enter location\n");
        
        //scanf("%c",&location);
         location=getch();
        
        if(location== 'c')
        {
                      printf("person  live in city\n");
                      printf("And his policy amount can not exceed :%d\n",amount1);
                      }
        else
        {
            printf("person live in village\n");
            printf("And his policy amount can not exceed:%d\n",amount3);
            }
        printf("if person is stisfy enter S\n");
         satisfy =getch();
 
          if(satisfy == 'S')
          {
                    printf(" person satisfies all the above conditions\n");
                    printf("sex is female and her premium is 3 per thousand\n");
                    printf("and his policy can not exceed:%d\n",amount4); 
                    }
                    else{
                    printf("In all other cases the person is not insured\n");
                    }
                   
    getch();
    }

