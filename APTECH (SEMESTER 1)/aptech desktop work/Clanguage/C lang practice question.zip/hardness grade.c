#include<stdio.h>
#include<conio.h>
int main()
{
    
    int num1;
    int f;
    int num2;
    printf("Hardness must be greater than 50\n");
    printf("Carbon content must be less than 0.7\n");
    printf("Tensile strength must be greater than 5600\n");
   
   
   
   
   
   printf("enter hardness value");
   scanf("%d",&num1);
   if(num1>=50)
   {
              printf("your grade is 10 you are met all three conditions\n" );
              }
    else{
    printf("your grade is 6 only one condition are met");
}
    
   printf("enter carbon float value\n");
   scanf("%f",&f);
   if(f<=0.7)
   {
             printf("your grade is 9 condition (i)and(ii) are met");
             }
             else{
                  printf("you are not ellegible to enter another number\n "); 
                  }
   printf("enter tensile strength");
   scanf("%d",&num2);
   if(num2>=5600)
   {
                printf("your grade is 8 (i)and (iii) condition are met\n");
                }
                else
                {
                    printf("your grade is 7 (i)and(iii) condition are met\n");
                    
                    }
                    printf("your grade is 5 none of the condition are met\n");
   
   
    
    
    
    getch();
    
    }
