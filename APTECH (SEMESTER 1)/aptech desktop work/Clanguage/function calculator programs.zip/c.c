#include<stdio.h>
#include<conio.h>
void sum(int a,int b);
int multiplication(int d, int f );
void average(int s , int r);
int subtraction(int g,int y);
void table (int c);





int main()
{
    int value1;
    int value2;
    printf("Please Enter The values of  sum is\n\n\n");
    printf("Value 1:");
    scanf("%d",&value1);
     printf("Value 2:");
    scanf("%d",&value2);
    
    sum(value1,value2);
    
    printf("Please Enter The values of  multiply is\n\n\n");
    printf("Value 1:");
    scanf("%d",&value1);
     printf("Value 2:");
    scanf("%d",&value2);
    multiplication(value1, value2);
    
    
     printf("Please Enter The values of  division is\n\n\n");
    printf("Value 1:");
    scanf("%d",&value1);
     printf("Value 2:");
    scanf("%d",&value2);
    average(value1, value2);
    
    printf("Please Enter The values of  subtraction is\n\n\n");
    printf("Value 1:");
    scanf("%d",&value1);
     printf("Value 2:");
    scanf("%d",&value2);
   subtraction(value1, value2);
   
    
     
    
   table(4);
    getch();
}
void sum(int a,int b)

{
    
 int result=a+b;
 printf("The sum is:%d\n",result); 
  
} 
int multiplication(int d, int f )
{
    int result =d*f;
     printf("The multiplication is:%d\n",result); 
    
    }
    void average(int s, int r)
    {
        int result = s+r;
        printf("the division is:%d\n",result/2);
        }
        int subtraction(int g,int y)
        {
            int t = g-y;
             printf("The subtraction is:%d\n",t); 
            }
            void table (int c)
            
                 {
              int e;
              for(e=1;e<=10;e++)
              printf("%dx%d =%d\n",c,e,c*e);
              
              
              }
                 
