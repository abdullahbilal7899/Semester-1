#include<stdio.h>
#include<conio.h>
int main()
{
    int a;
    int b;
    int c;
    int d;
    int sum;
   
    scanf("%d",&a);
 
    scanf("%d",&b);
    
    scanf("%d",&c);
  
    scanf("%d",&d);
   
     sum = a+d;
     printf("the a and d value sum is :%d",sum);
    
    getch();
    }
