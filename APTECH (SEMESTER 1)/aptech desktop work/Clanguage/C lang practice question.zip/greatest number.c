#include <stdio.h> 
#include <conio.h>
int main()
{
int a,b,c;
printf("enter 3 numbers (a,b,c)to find greatest no: ");
scanf("%d%d%d",&a,&b,&c);
(a>b&&a>c)?printf("a is greatest"):((b>a&&b>c)?printf("b is greatest"):printf("c is greatest"));

printf ("\n\nPress any key to close.");

getch ();
return 0;
}
