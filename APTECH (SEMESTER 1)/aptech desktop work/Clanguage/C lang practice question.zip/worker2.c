#include<stdio.h>
#include<conio.h>
int main()
{
    int hour1;
    int hour2;
    int hour3;
    int hour4;
    printf("time required for a worker to complete a particular job\n");
    printf("find the efficiency of the worker\n");
    printf("2-3 hour\n");
    printf("3-4 hour\n");
    printf("4-5 hour\n");
    printf("more rthan 5 hours\n");
    printf("enter working hours between 2-3\n");
    scanf("%d",&hour1);
    if(hour1 ==2||hour1==3)
    {
             printf("worker is highly efficient\n");
             }
             else{
                  printf("worker is not efficient\n");
                  }
                  
                  
                  //printf("enter working hours between 3-4\n");
                  scanf("%d",&hour2);
    if(hour2 ==3||hour2==4)
    {
             printf("worker speed is improved\n"); 
             }
             else{
                  printf("worker speed is not improved\n"); 
                  }
                  
             // printf("enter working hour between 4-5\n");
              scanf("%d",&hour3);
    
     if(hour3==4|| hour3==5)
     {
                   printf("worker is given training to improve his speed\n");
                   }        
                  else
                  {
                      printf("worker is not given training and not improve his speed\n");
                      }
                      //printf("enter more than 5 working hours\n");
                      scanf("%d",&hour4);
      if(hour4 >=5) 
      {
               printf("worker has to leave the company\n");
               }           
              else
              {
                  printf("worker has not to leave the company\n");
                  }
    getch();
    }
