#include<stdio.h>
#include<conio.h>
int main()
{
    int a;
    int b;
    int c;
    int d;
    
    printf("enter  number ");
    scanf("%d",&a);
    printf("enter  number ");
    scanf("%d",&b);
    printf("enter  number ");
    scanf("%d",&c);
    printf("enter  number ");
    scanf("%d",&d);
    
    

  printf("Enter a number: ");
  scanf("%d", &a);

  for(a = d; d > 0; d--) 
      printf("%d\n",d);
  
  printf("\a");

getch(); 
}
