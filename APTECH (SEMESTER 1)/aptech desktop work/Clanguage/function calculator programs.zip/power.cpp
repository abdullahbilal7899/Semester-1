#include <stdio.h>      
#include <conio.h>      

int main()
{
    int power;
    int base;
   printf (" enter power " );
   scanf("%d",&power);
   printf (" enter base " );
  scanf("%d",&base);
  base=base^power;
  printf("the power is:%d\n",base);
  getch();
   return 0;
}
