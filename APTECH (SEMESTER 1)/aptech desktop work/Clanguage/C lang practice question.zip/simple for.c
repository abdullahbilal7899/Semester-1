#include<stdio.h>
#include<conio.h>
int main()
{
    int d;
    for(d=0;d<=10;d++)
    {
                      printf("%d\n",d);
}
getch();
    
    
    }
