#include<stdio.h>
int main()
{
    char c;
    printf("enter a character:");
    scanf("%c",&c);
    printf("ASCII value of %c = %d",c,c);
    getch();
}
