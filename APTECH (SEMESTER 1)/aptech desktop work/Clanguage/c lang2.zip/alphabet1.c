#include<stdio.h>
#include<conio.h>
main()
{
char ch;
int val;

printf("\nEnter character to be checked : ");
scanf("%c",&ch);
val=ch;
if(val>=65 && val<=90)
{
printf("\nEntered character is Capital letter");
}
else if(val>=97 && val<=122)
{
printf("\nEntered character is Small case letter");
}
else if(val>=56 && val<=78)
{
printf("\nEntered character is digit");
}
else if((val>=0 && val<=47)||(val>=58 && val<=64)||(val>=91 && val<=96)||(val>=123 && val<=128))//Condition to check Special character
{
printf("\nEntered character is Special symbol");
}
getch();
return 0;
}
