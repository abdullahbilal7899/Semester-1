#include<stdio.h>
#include<conio.h>
int main()
{
    int year;
    printf("Enter a year:");
scanf("%d", &year);

(year%4==0)?(printf("Leap Year")):(printf("Not a Leap Year"));

    getch();
    }
