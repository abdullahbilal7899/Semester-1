#include<stdio.h>
#include<conio.h>
int main()
{
    int base ;
    int power;
    int value,v=1 ;
    printf("enter base");
    scanf("%d",&base);
    printf("enter power");
    scanf("%d",&power);
    for(value=1;value<=power;value++){
    v=v*base;
    //printf("%d raised to the power of %d ", base, power, value);
}
    printf("the power is %d\n",v);
    
    
    
    
    getch();
    }
