#include<stdio.h>
#include<conio.h>
int main()
{
    int sum=0;
    int a;
    for( a=1;a<=30;a++)
    {
    printf("%d\n",a);
    sum = sum + a;
}
    printf("total of sum is %d\n",sum);
   
    
    
    
    
    
    getch();
    }
